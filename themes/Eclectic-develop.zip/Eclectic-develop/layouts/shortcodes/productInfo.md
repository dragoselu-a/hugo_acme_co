We make over ***200 shapes***. The most popular of these include:

Shape | Design | Description | Links
---   |  ---   |   ---       | ---
Line | -- | Two pointy ends and a straight stretch of ink | [Line on Wikipedia](https://en.wikipedia.org/wiki/Line_(geometry))
Circle  | &#8413; | A full round with no corners | [Circle on Wikipedia]
Triangle  | &#9651; | Three lines with three corners |  [Triangle on Wikipedia](https://en.wikipedia.org/wiki/Triangle)

[Circle on Wikipedia]: https://en.wikipedia.org/wiki/Circle
