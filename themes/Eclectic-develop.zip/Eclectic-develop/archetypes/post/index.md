---
date: {{ .Date }}
type: post
title: "{{ replace .Name "-" " " | title }}"
description: "Placeholder"
draft: true
tags:
sidebar:
  - title: attribution
    content: "Image by author  from [Website](Link)"
categories:
  - general
---
